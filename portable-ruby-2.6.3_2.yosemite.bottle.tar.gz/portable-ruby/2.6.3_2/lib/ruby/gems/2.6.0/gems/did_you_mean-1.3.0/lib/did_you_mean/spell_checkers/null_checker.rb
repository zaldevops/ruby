module DidYouMean
  class NullChecker
    def initialize(*);  end
    def corrections; [] end
  end
end
