require 'did_you_mean'
require 'did_you_mean/formatters/verbose_formatter'

DidYouMean.formatter = DidYouMean::VerboseFormatter.new
